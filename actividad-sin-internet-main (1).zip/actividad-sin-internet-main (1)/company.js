template = "";

fetch("http://localhost:3000/companies")
  .then((result) => result.json())
  .then((data) => {
    let tbody = document.getElementById("tbody");
    data.forEach((element) => {
      //let tr = document.createElement("tr");
      //tbody.appendChild(tr);
      //template = document.getElementById("tbody");
      template +=`<tr>
          <td>${element.id}</td>
          <td style="text-transform: uppercase">${element.name}</td>
          <td>${element.description}</td>
          <td>${element.founder}</td>
          <td><img src="${element.logo}" style="height: 3rem; width: auto;"></td>
          <td>
          <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modal_detail" onclick="detallesEmpleado('${element.id}')">Detalle</button>
          <button class="btn btn-danger btn-sm" onclick="eliminar('${element.id}')">Eliminar</button>
          <button data-bs-toggle="modal" data-bs-target="#modal_edit" class="btn btn-primary btn-sm" onclick="editar('${element.id}')">Editar</button>
          </td>
          </tr>`;

      tbody.innerHTML = template;
      /*
      let td_id = document.createElement("td");
      td_id.innerText = element.id;
      tr.appendChild(td_id);

      let td_name = document.createElement("td");
      td_name.innerText = element.name;
      tr.appendChild(td_name);

      let td_description = document.createElement("td");
      td_description.innerText = element.description;
      tr.appendChild(td_description);

      let td_founder = document.createElement("td");
      td_founder.innerText = element.founder;
      tr.appendChild(td_founder);

      let td_logo = document.createElement("td");
      tr.appendChild(td_logo);

      let img_logo = document.createElement("img");
      img_logo.setAttribute("src", element.logo);
      img_logo.style.height = "3rem";
      img_logo.style.width = "auto";
      td_logo.appendChild(img_logo);

      let td_actions = document.createElement("td");
      let button_detail = document.createElement("button");
      button_detail.classList.add("btn", "btn-warning", "btn-sm");
      button_detail.innerText = "Detalle";
      td_actions.appendChild(button_detail);

      let button_delete = document.createElement("button");
      button_delete.classList.add("btn", "btn-danger", "btn-sm");
      button_delete.innerText = "Eliminar";
      button_delete.setAttribute("onclick", "eliminar('" + element.id + "')");
      td_actions.appendChild(button_delete);

      let button_edit = document.createElement("button");
      button_edit.classList.add("btn", "btn-primary", "btn-sm");
      button_edit.innerText = "Editar";
      td_actions.appendChild(button_edit);
      tr.appendChild(td_actions); 
      */
    });
  });

/*   funcion para crear */

function crearNuevaEmpresa() {
  let name = document.getElementById("name_create");
  let description = document.getElementById("description_create");
  let founder = document.getElementById("founder_create");
  let logo = document.getElementById("logo_create");
  let webSite = document.getElementById("webSite_create");

  let data_user = {
    name: name.value,
    description: description.value,
    founder: founder.value,
    logo: logo.value,
    webSite: webSite.value,
  };

  fetch("http://localhost:3000/companies", {
    method: "POST",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((result) => result.json())
    .then((data) => {
      location.href = "";
      console.log(data);
    });
}

/* función para eliminar */

function eliminar(id) {
  fetch("http://localhost:3000/companies/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((result) => result.json())
    .then((data) => {
      location.href = ""
    });
}

/* función para rellenar el modal a editar*/

function editar(id) {
  fetch("http://localhost:3000/companies/" + id)
    .then(result => result.json())
    .then(data => {
      document.getElementById("name_edit").value = data.name
      document.getElementById("description_edit").value = data.description
      document.getElementById("founder_edit").value = data.founder
      document.getElementById("logo_edit").value = data.logo
      document.getElementById("webSite_edit").value = data.webSite
      document.getElementById("id_edit").value = data.id
    })
}

/* función para actualizar el modal rellenado */

function actualizar() {
  let name = document.getElementById("name_edit")
  let description = document.getElementById("description_edit")
  let founder = document.getElementById("founder_edit")
  let logo = document.getElementById("logo_edit")
  let webSite = document.getElementById("webSite_edit")
  let id = document.getElementById("id_edit")

  let data_user = {
    name: name.value,
    description: description.value,
    founder: founder.value,
    logo: logo.value,
    webSite: webSite.value
  }

  fetch("http://localhost:3000/companies/" + id.value, {
    method: "PUT",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
    })

}

template_detail = ""
template_detail2 = ""
function detallesEmpleado(id) {
  fetch("http://localhost:3000/companies/" + id)
    .then(result => result.json())
    .then(data => {
      let tbody_detail = document.getElementById("tbody_detail")
      template_detail = `
      <tr>
        <th>Empresa:</th>
        <td>${data.name}</td>
      </tr>
      <tr>
        <th>Descripción:</th>
        <td>${data.description}</td>
      </tr>
      <tr>
        <th>Fundador:</th>
        <td>${data.founder}</td>
      </tr>
      <tr>
        <th>Logo:</th>
        <td><img src="${data.logo}" style="height: 3rem; width: auto;"></td>
      </tr>
      <tr>
        <th>Sitio web:</th>
        <td><a href="${data.webSite}" target="_blank">Visitar</a></td>
      </tr>
      `
      tbody_detail.innerHTML = template_detail

      fetch("http://localhost:3000/employees/")
        .then(r => r.json())
        .then(d => {

        usuario_company = d.filter(function (element) {
          return element.id_company == data.id;
        })

        let tbody_detail2 = document.getElementById("tbody_detail2")
        usuario_company.forEach(function (element) {
          template_detail2 += `
          <tr>
            <th>Nombre:</th>
            <td>${element.name}</td>
          </tr>
          <tr>
            <th>Apellidos:</th>
            <td>${element.lastName}</td>
          </tr>
          <tr>
            <th>email:</th>
            <td>${element.email}</td>
          </tr>
          <tr>
            <th>Cargo/Puesto:</th>
            <td>${element.position}</td>
          </tr>
          <tr>
            <th>Fecha de ingreso:</th>
            <td>${element.date}</td>
          </tr>
          <tr>
            <th>Hoja de vida:</th>
            <td><a href="${element.cv}" target="_blank">Descargar</a></td>
          </tr>
          <tr>
            <th>Sitio web:</th>
            <td><a href="${element.webSite}" target="_blank">Visitar</a></td>
          </tr>
          <td>------------------------------</td>
          `
        })
        
        tbody_detail2.innerHTML = template_detail2
        
      })
    })
}

function restart() {
  location.href = ""
}