template = "";

fetch("http://localhost:3000/employees")
  .then((result) => result.json())
  .then((data) => {
    let tbody = document.getElementById("tbody");
    data.forEach((element) => {
      template += `
      <tr>
        <td>${element.id}</td>
        <td>${element.name}</td>
        <td>${element.lastName}</td>
        <td>${element.email}</td>
        <td>${element.position}</td>
        <td>${element.date}</td>
        <td><a href="${element.cv}" target="_blank">Descargar CV</a></td>
        <td><a href="${element.webSite}" target="_blank">Visitar sitio</a></td>
        <td>
          <a class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modal_detail" onclick="detallesEmpleado('${element.id}')">Detalle</a>
          <a class="btn btn-danger btn-sm" onclick="eliminar('${element.id}')">Eliminar</a>
          <a class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modal_edit" onclick="editar('${element.id}')">Editar</a>
        </td>
      </tr>
      `;
      tbody.innerHTML = template;

      /* let tr = document.createElement("tr")
      tbody.appendChild(tr)

      let td_id = document.createElement("td")
      td_id.innerText = element.id
      tr.appendChild(td_id)

      let td_name = document.createElement("td")
      td_name.innerText = element.name
      tr.appendChild(td_name)

      let td_lastName = document.createElement("td")
      td_lastName.innerText = element.lastName
      tr.appendChild(td_lastName)

      let td_email = document.createElement("td")
      td_email.innerText = element.email
      tr.appendChild(td_email)

      let td_position = document.createElement("td")
      td_position.innerText = element.position
      tr.appendChild(td_position)

      let td_date = document.createElement("td")
      td_date.innerText = element.date
      tr.appendChild(td_date)

      let td_cv = document.createElement("td")
      td_cv.innerText = element.cv
      tr.appendChild(td_cv)

      let a_cv = document.createElement('a');
      a_cv.innerText = " descargar CV";
      a_cv.setAttribute("href", element.cv)
      a_cv.setAttribute("target", "_blank")
      td_cv.appendChild(a_cv);

      let td_webSite = document.createElement("td")
      td_webSite.innerText = element.webSite
      tr.appendChild(td_webSite)

      let a_webSite = document.createElement("a")
      a_webSite.innerText = " Visitar sitio"
      a_webSite.setAttribute("href", element.webSite)
      a_webSite.setAttribute("target", "_blank")
      td_webSite.appendChild(a_webSite) 

      let td_actions = document.createElement("td")
      tr.appendChild(td_actions)

      let button_detail = document.createElement("button")
      button_detail.classList.add("btn", "btn-warning", "btn-sm")
      button_detail.innerText = "Detalle"
      td_actions.appendChild(button_detail)

      let button_delete = document.createElement("button")
      button_delete.classList.add("btn", "btn-danger", "btn-sm")
      button_delete.innerText = "Eliminar"
      button_delete.setAttribute("onclick", "eliminar('" + element.id + "')")
      td_actions.appendChild(button_delete)

      let button_edit = document.createElement("button")
      button_edit.classList.add("btn", "btn-primary", "btn-sm")
      button_edit.innerText = "Editar"
      td_actions.appendChild(button_edit) */
    });
  });

/* funcion crear nuevos usuarios */

function crearNuevoUsuario() {
  let name = document.getElementById("name_create");
  let lastName = document.getElementById("lastName_create");
  let email = document.getElementById("email_create");
  let position = document.getElementById("position_create");
  let date = document.getElementById("date_create");
  let cv = document.getElementById("cv_create");
  let webSite = document.getElementById("webSite_create");
  let id_company = document.getElementById("select_create");

  let data_user = {
    name: name.value,
    lastName: lastName.value,
    email: email.value,
    position: position.value,
    date: date.value,
    cv: cv.value,
    webSite: webSite.value,
    id_company: id_company.value,
  };

  fetch("http://localhost:3000/employees", {
    method: "POST",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((result) => result.json())
    .then((data) => {
      location.href = "";
      console.log(data);
    });
}

/* funcion para eliminar  */

function eliminar(id) {
  fetch("http://localhost:3000/employees/" + id, {
    method: "DELETE",
    headers: {
      "content-Type": "application/json",
    },
  })
    .then((result) => result.json())
    .then((data) => {
      location.href = "";
    });
}

/* función rellenar y editar*/

function editar(id) {
  fetch("http://localhost:3000/employees/" + id)
    .then((result) => result.json())
    .then((data) => {
      document.getElementById("name_edit").value = data.name;
      document.getElementById("lastName_edit").value = data.lastName;
      document.getElementById("email_edit").value = data.email;
      document.getElementById("position_edit").value = data.position;
      document.getElementById("date_edit").value = data.date;
      document.getElementById("cv_edit").value = data.cv;
      document.getElementById("webSite_edit").value = data.webSite;
      document.getElementById("id_edit").value = data.id;
    });
}

/* función para actualizar el modal rellenado */

function actualizar() {
  let name = document.getElementById("name_edit");
  let lastName = document.getElementById("lastName_edit");
  let email = document.getElementById("email_edit");
  let position = document.getElementById("position_edit");
  let date = document.getElementById("date_edit");
  let cv = document.getElementById("cv_edit");
  let webSite = document.getElementById("webSite_edit");
  let id = document.getElementById("id_edit");

  let data_user = {
    name: name.value,
    lastName: lastName.value,
    email: email.value,
    position: position.value,
    date: date.value,
    cv: cv.value,
    webSite: webSite.value,
  };

  fetch("http://localhost:3000/employees/" + id.value, {
    method: "PUT",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((result) => result.json())
    .then((data) => {
      location.href = "";
    });
}

/* funcion para mostrar detalles */

template_detail = "";
function detallesEmpleado(id) {
  fetch("http://localhost:3000/employees/" + id)
    .then((result) => result.json())
    .then((data) => {
      let tbody_detail = document.getElementById("tbody_detail");
      template_detail = `
      <tr>
        <th>Nombres:</th>
        <td>${data.name}</td>
      </tr>
      <tr>
        <th>Apellidos:</th>
        <td>${data.lastName}</td>
      </tr>
      <tr>
        <th>email:</th>
        <td>${data.email}</td>
      </tr>
      <tr>
        <th>Cargo/Puesto:</th>
        <td>${data.position}</td>
      </tr>
      <tr>
        <th>Fecha de ingreso:</th>
        <td>${data.date}</td>
      </tr>
      <tr>
        <th>Hoja de vida:</th>
        <td><a href="${data.cv}" target="_blank">Descargar</a></td>
      </tr>
      <tr>
        <th>Sitio web:</th>
        <td><a href="${data.webSite}" target="_blank">Visitar</a></td>
      </tr>
      `;
      tbody_detail.innerHTML = template_detail;

      fetch("http://localhost:3000/companies/" + data.id_company)
        .then((result) => result.json())
        .then((data) => {
          let tbody_detail2 = document.getElementById("tbody_detail2");
          template_datailEmpresa = `
          <tr>
            <th>Empresa:</th>
            <td>${data.name}</td>
          </tr>
          <tr>
            <th>Descripción:</th>
            <td>${data.description}</td>
          </tr>
          <tr>
            <th>Fundador:</th>
            <td>${data.founder}</td>
          </tr>
          <tr>
            <th>Logo:</th>
            <td><img src="${data.logo}" style="height: 3rem; width: auto;"></td>
          </tr>
          <tr>
            <th>Sitio web:</th>
            <td><a href="${data.webSite}" target="_blank">Visitar</a></td>
          </tr>
      `;
          tbody_detail2.innerHTML = template_datailEmpresa;
        });
    });
}

