fetch("http://localhost:3000/companies")
  .then(result => result.json())
  .then(data => {
    let tbody = document.getElementById("tbody")
    data.forEach(element => {
      
      let tr = document.createElement("tr")
      tbody.appendChild(tr)

      let td_id = document.createElement("td")
      td_id.innerText = element.id
      tr.appendChild(td_id)

      let td_name = document.createElement("td")
      td_name.innerText = element.name
      tr.appendChild(td_name)

      let td_description = document.createElement("td")
      td_description.innerText = element.description
      tr.appendChild(td_description)

      let td_founder = document.createElement("td")
      td_description.innerText = element.founder
      tr.appendChild(td_founder)

      let td_logo = document.createElement("td")
      tr.appendChild(td_logo)

      let img_logo = document.createElement("img")
      img_logo.setAttribute("src", element.logo)
      img_logo.style.height = "3rem"
      img_logo.style.width = "auto"
      td_logo.appendChild(img_logo)

    });
  })

function crearNuevaEmpresa() {
  let name = document.getElementById("name_create")
  let description = document.getElementById("description_create")
  let founder = document.getElementById("founder_create")
  let logo = document.getElementById("logo_create")
  let webSite = document.getElementById("webSite_create")

  let data_user = {
    name: name.value,
    description: description.value,
    founder: founder.value,
    logo: logo.value,
    webSite: webSite.value
  }

  fetch("http://localhost:3000/companies", {
    method: "POST",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
      console.log(data)
    })
  
  }