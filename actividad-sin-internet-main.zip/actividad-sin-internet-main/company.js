fetch("http://localhost:3000/companies")
  .then(result => result.json())
  .then(data => {
    let tbody = document.getElementById("tbody")
    data.forEach(element => {

      let tr = document.createElement("tr")
      tbody.appendChild(tr)

      let td_id = document.createElement("td")
      td_id.innerText = element.id
      tr.appendChild(td_id)

      let td_name = document.createElement("td")
      td_name.innerText = element.name
      tr.appendChild(td_name)

      let td_description = document.createElement("td")
      td_description.innerText = element.description
      tr.appendChild(td_description)

      let td_founder = document.createElement("td")
      td_founder.innerText = element.founder
      tr.appendChild(td_founder)

      let td_logo = document.createElement("td")
      tr.appendChild(td_logo)

      let img_logo = document.createElement("img")
      img_logo.setAttribute("src", element.logo)
      img_logo.style.height = "3rem"
      img_logo.style.width = "auto"
      td_logo.appendChild(img_logo)

      let td_actions = document.createElement("td")
      let button_detail = document.createElement("button")
      button_detail.classList.add("btn", "btn-warning", "btn-sm")
      button_detail.innerText = "Detalle"
      td_actions.appendChild(button_detail)

      let button_delete = document.createElement("button")
      button_delete.classList.add("btn", "btn-danger", "btn-sm")
      button_delete.innerText = "Eliminar"
      button_delete.setAttribute("onclick", "eliminar(" + element.id + ")")
      td_actions.appendChild(button_delete)

      let button_edit = document.createElement("button")
      button_edit.classList.add("btn", "btn-primary", "btn-sm")
      button_edit.innerText = "Editar"
      td_actions.appendChild(button_edit)
      tr.appendChild(td_actions)

    });
  })

 /*  funcion para crear empresa */

function crearNuevaEmpresa() {
  let name = document.getElementById("name_create")
  let description = document.getElementById("description_create")
  let founder = document.getElementById("founder_create")
  let logo = document.getElementById("logo_create")
  let webSite = document.getElementById("webSite_create")

  let data_user = {
    name: name.value,
    description: description.value,
    founder: founder.value,
    logo: logo.value,
    webSite: webSite.value
  }

  fetch("http://localhost:3000/companies", {
    method: "POST",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
      console.log(data)
    })

}

/* funcion para eliminar empresa */

function eliminar(id){
  fetch("http://localhost:3000/companies" + id, {
  method: "DELETE",
  headers: {
    "Content-Type" : "application/json"
  }
  })
    .then(result => result.json())
    .then((data) => {
      location.href = ""
    })

  
}
