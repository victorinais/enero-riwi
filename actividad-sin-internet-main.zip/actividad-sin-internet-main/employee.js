
fetch("http://localhost:3000/employees")
  .then(result => result.json())
  .then(data => {
    let tbody = document.getElementById("tbody")
    data.forEach((element) => {

      let tr = document.createElement("tr")
      tbody.appendChild(tr)

      let td_id = document.createElement("td")
      td_id.innerText = element.id
      tr.appendChild(td_id)

      let td_name = document.createElement("td")
      td_name.innerText = element.name
      tr.appendChild(td_name)

      let td_lastName = document.createElement("td")
      td_lastName.innerText = element.lastName
      tr.appendChild(td_lastName)

      let td_email = document.createElement("td")
      td_email.innerText = element.email
      tr.appendChild(td_email)

      let td_position = document.createElement("td")
      td_position.innerText = element.position
      tr.appendChild(td_position)

      let td_date = document.createElement("td")
      td_date.innerText = element.date
      tr.appendChild(td_date)

      let td_cv = document.createElement("td")
      td_cv.innerText = element.cv
      tr.appendChild(td_cv)

      let a_cv = document.createElement('a');
      a_cv.innerText = " descargar CV";
      a_cv.setAttribute("href", element.cv)
      a_cv.setAttribute("target", "_blank")
      td_cv.appendChild(a_cv);

      let td_webSite = document.createElement("td")
      td_webSite.innerText = element.webSite
      tr.appendChild(td_webSite)

      let a_webSite = document.createElement("a")
      a_webSite.innerText = " Visitar sitio"
      a_webSite.setAttribute("href", element.webSite)
      a_webSite.setAttribute("target", "_blank")
      td_webSite.appendChild(a_webSite) 

      let td_actions = document.createElement("td")
      let button_detail = document.createElement("button")
      button_detail.classList.add("btn", "btn-warning", "btn-sm")
      button_detail.innerText = "Detalle"
      td_actions.appendChild(button_detail)

      let button_delete = document.createElement("button")
      button_delete.classList.add("btn", "btn-danger", "btn-sm")
      button_delete.innerText = "Eliminar"
      button_delete.setAttribute("onclick", )
      td_actions.appendChild(button_delete)

      let button_edit = document.createElement("button")
      button_edit.classList.add("btn", "btn-primary", "btn-sm")
      button_edit.innerText = "Editar"
      td_actions.appendChild(button_edit)
      tr.appendChild(td_actions)
      
    });
  })

/* funcion crear nuevos usuarios */

function crearNuevoUsuario() {
  let name = document.getElementById("name_create")
  let lastName = document.getElementById("lastName_create")
  let email = document.getElementById("email_create")
  let position = document.getElementById("position_create")
  let date = document.getElementById("date_create")
  let cv = document.getElementById("cv_create")
  let webSite = document.getElementById("webSite_create")

  let data_user = {
    name: name.value,
    lastName: lastName.value,
    email: email.value,
    position: position.value,
    date: date.value,
    cv: cv.value,
    webSite: webSite.value
  }

  fetch("http://localhost:3000/employees", {
    method: "POST",
    body: JSON.stringify(data_user),
    headers: {
      "Content-Type": "application/json"
    }
  })
    .then(result => result.json())
    .then(data => {
      location.href = ""
      console.log(data)
    })
  
  }