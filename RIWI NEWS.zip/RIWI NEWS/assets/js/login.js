/* login */
template_login = ""
let login = document.getElementById("login")
template_login = `
<form class="border p-4 rounded-3 m-5 ">
  <div class="mb-3">
    <label for="Email" class="form-label">Email address</label>
    <input type="email" class="form-control" id="Email" aria-describedby="emailHelp">
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
  </div>
  <div class="mb-3">
    <label for="Password" class="form-label">Password</label>
    <input type="password" class="form-control" id="Password">
  </div>
  <button type="button" class="btn btn-primary" onclick="verifyUser()">Submit</button>
</form>
`
login.innerHTML = template_login

/* verificar usuario */
function verifyUser(){
  let email = document.getElementById("Email")
  let password = document.getElementById("Password")
  
  fetch("http://localhost:3000/users")
  .then(result => result.json())
  .then(data => {
    let resultado = data.filter(item => {
      if(item.email == email.value){
        return item
      }
    })
    
    if(resultado.length > 0){
      if(resultado[0].password == password.value){
        console.log("correo y contraseña correctas")
        localStorage.setItem("autenticación", "si")
        localStorage.setItem("nombre", resultado[0].name)
        location.href = "./../html/admin.html"
      } else {
        console.log("Correo o contraseña incorrectos")
      } 
    } else {
      console.log("No hay coincidencias")
    }
  })
}

