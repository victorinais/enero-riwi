/* obtenemos el nombre y la autenticación */
let nombre = localStorage.getItem("nombre")
let authentication = localStorage.getItem("autenticación")

document.getElementById("name").innerText = nombre
if (authentication != "si") {
  location.href = "./../html/index.html"
}

template_nav_table = ""
let main1 = document.getElementById("main1")
template_nav_table = `
    <ul class="nav nav-tabs" id="myTab" role="tablist">
      <li class="nav-item" role="presentation">
        <button
          class="nav-link active"
          id="home-tab"
          data-bs-toggle="tab"
          data-bs-target="#home-tab-pane"
          type="button"
          role="tab"
          aria-controls="home-tab-pane"
          aria-selected="true">
          Categories
        </button>
      </li>
      <li class="nav-item" role="presentation">
        <button
          class="nav-link"
          id="profile-tab"
          data-bs-toggle="tab"
          data-bs-target="#profile-tab-pane"
          type="button"
          role="tab"
          aria-controls="profile-tab-pane"
          aria-selected="false">
          Notices
        </button>
      </li>
      <li class="d-block mx-5">
        <button type="button" class="btn btn-danger" id="close" onclick="close()">Go Out</button>
      </li>
    </ul>
  `
  main1.innerHTML = template_nav_table

/* cabeceras de la tabla */
template_head_table = ""
let main2 = document.getElementById("main2")
template_head_table = `
<div class="tab-content" id="myTabContent">
  <div
    class="tab-pane fade show active"
    id="home-tab-pane"
    role="tabpanel"
    aria-labelledby="home-tab"
    tabindex="0">
    <h1 class="text-center mt-3">Categories</h1>
    <div class="d-flex w-100 justify-content-end">
      <!-- Button trigger modal -->
        <button
          type="button"
          class="btn btn-primary"
          data-bs-toggle="modal"
          data-bs-target="#modal-category">
          Add new Category
        </button>
    </div>
    <div class="row justify-content-center">
      <div class="col-md-12 mt-2">
        <div class="card">
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>NAME</th>
                    <th>DESCRIPTION</th>
                    <th>ACTIONS</th>
                  </tr>
                </thead>
                <tbody id="tbody_categories">
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div
    class="tab-pane fade"
    id="profile-tab-pane"
    role="tabpanel"
    aria-labelledby="profile-tab"
    tabindex="0">
    <h1 class="text-center mt-3">Notices</h1>
      <div class="d-flex w-100 justify-content-end">
        <!-- Button trigger modal -->
        <button
          type="button"
          class="btn btn-primary"
          data-bs-toggle="modal"
          data-bs-target="#modal-notice">
          Add new Notice
        </button>
      </div>
      <div class="row justify-content-center">
        <div class="col-md-12 mt-2">
          <div class="card">
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-striped table-hover">
                  <thead>
                    <tr>
                      <th>IMAGE</th>
                      <th>TITLE</th>
                      <th>CONTENT</th>
                      <th>PUBLICATION DATE</th>
                      <th>AUTHOR</th>
                      <th>CATEGORY</th>
                      <th>ACTIONS</th>
                    </tr>
                  </thead>
                  <tbody id="tbody_notices">
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
`
main2.innerHTML = template_head_table

/* petición para mostrar categorias */
let template_categories = ""
fetch("http://localhost:3000/categories")
.then(result => result.json())
.then(data => {
  let tbody = document.getElementById("tbody_categories")
  data.forEach(item => {
    template_categories += `
      <tr>
        <td>${item.id}</td>
        <td>${item.name}</td>
        <td>${item.description}</td>
        <td>
          <button class="btn btn-primary btn-sm" type="button" 
          data-bs-toggle="modal" data-bs-target="#modal-category-edit"
          onclick="fillCategory('${item.id}')">Edit</button>
          <button class="btn btn-danger btn-sm" onclick="deleteCategory('${item.id}')">Delete</button>
        </td>
      </tr>
      `
    tbody.innerHTML = template_categories
  })
})

/* funcion para crear categoria */
function createCategory(){
  let name = document.getElementById("nameCategory")
  let description = document.getElementById("descriptionCategory")

  datos_category = {
    name: name.value,
    description: description.value
  }

  fetch("http://localhost:3000/categories", {
    method: "POST",
    body: JSON.stringify(datos_category),
    headers: {
      "Content-Type": "application/json"
    }
  })
  .then(result => result.json())
  .then(data => {
    location.href = ""
  })
}

/* función para eliminar categoria */
function deleteCategory(id){
  fetch("http://localhost:3000/categories/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    }
  })
  .then(result => result.json())
  .then(data => {
    location.href = ""
  })
}

/* función para llenar modal editar categoria */
function fillCategory(id){
  fetch("http://localhost:3000/categories/" + id)
  .then(result => result.json())
  .then(data => {
    document.getElementById("nameCategoryEdit").value = data.name,
    document.getElementById("descriptionCategoryEdit").value = data.description
    document.getElementById("categoryEdit").value = data.id
  })
}

/* función para editar y guardar categoria */
function editCategory(){
  let name = document.getElementById("nameCategoryEdit")
  let description = document.getElementById("descriptionCategoryEdit")
  let id = document.getElementById("categoryEdit")

  datos_category = {
    name: name.value,
    description: description.value
  }

  fetch("http://localhost:3000/categories/" + id.value, {
    method: "PUT",
    body: JSON.stringify(datos_category),
    headers: {
      "Content-Type": "application/json"
    }
  })
  .then(result => result.json())
  .then(data => {
    location.href = ""
  })
}

/* petición para mostrar noticias */
let template_notices = ""
fetch("http://localhost:3000/news")
.then(result => result.json())
.then(data => {
  let tbody = document.getElementById("tbody_notices")
  data.forEach(item => {
    template_notices += `
      <tr>
        <td>
          <img src="${item.img}" style="height: 2rem;border-radius: 25%"></img>
        </td>
        <td>${item.title}</td>
        <td>${item.content}</td>
        <td>${item.publicationDate}</td>
        <td>${item.name}</td>
        <td>${item.idCategory}</td>
        <td>
          <button class="btn btn-primary btn-sm" type="button"
          data-bs-toggle="modal" data-bs-target="#modal-notice-update" 
          onclick="fillModalEdit('${item.id}')">Edit</button>
          <button class="btn btn-danger btn-sm" onclick="deleteNotice('${item.id}')">Delete</button>
        </td>
      <tr>
    `
    tbody.innerHTML = template_notices
  })
})

/* función para crear noticia */
function createNotice(){
  let title = document.getElementById("nameNotice")
  let img = document.getElementById("urlImage")
  let idCategory = document.getElementById("idCategory")
  let content = document.getElementById("contentNotice")
  let name = document.getElementById("author")
  let publicationDate = document.getElementById("publicationDate")

  data_notice = {
    title: title.value,
    img: img.value,
    idCategory: idCategory.value,
    content: content.value,
    name: name.value,
    publicationDate: publicationDate.value
  }

  fetch("http://localhost:3000/news", {
    method: "POST",
    body: JSON.stringify(data_notice),
    headers: {
      "Content-Type": "application/json"
    }
  })
  .then(result => result.json())
  .then(data => {
    location.href = ""
  })
}

/* funcion para eliminar noticia */
function deleteNotice(id){
  fetch("http://localhost:3000/news/" + id, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    }
  })
  .then(result => result.json())
  .then(data => {
    location.href = ""
  })
}

/* función para rellenar modal editar noticia*/
function fillModalEdit(id){
  fetch("http://localhost:3000/news/" + id)
    .then(result => result.json())
    .then(data => {
      document.getElementById("nameNoticeEdit").value = data.title
      document.getElementById("urlImageEdit").value = data.img
      document.getElementById("idCategoryEdit").value = data.idCategory
      document.getElementById("contentNoticeEdit").value = data.content
      document.getElementById("author").value = data.name
      document.getElementById("publicationDateEdit").value = data.publicationDate
      document.getElementById("idEdit").value = data.id

    })
}

/* función para editar y guardar noticia */
function editNotice(){
  let title = document.getElementById("nameNoticeEdit")
  let img = document.getElementById("urlImageEdit")
  let idCategory = document.getElementById("idCategoryEdit")
  let content = document.getElementById("contentNoticeEdit")
  let name = document.getElementById("author")
  let publicationDate = document.getElementById("publicationDateEdit")
  let id = document.getElementById("idEdit")

  data_notice = {
    title: title.value,
    img: img.value,
    idCategory: idCategory.value,
    content: content.value,
    name: name.value,
    publicationDate: publicationDate.value
  }

  fetch("http://localhost:3000/news/" + id.value, {
    method: "PUT",
    body: JSON.stringify(data_notice),
    headers: {
      "Content-Type": "application/json"
    }
  })
  .then(result => result.json())
  .then(data => {
    location.href = ""
  })
}

/* funcion para cerrar sesión */
if (localStorage.getItem("autenticación") == "si"){
  let btn = document.getElementById("close")
  btn.addEventListener("click", close)
  function close(){
    localStorage.setItem("nombre", "")
    localStorage.setItem("autenticación", "")
    location.href = "../html/index.html"
  }
}