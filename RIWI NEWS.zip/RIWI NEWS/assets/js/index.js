/* petición GET para mostrar noticias */
template_news = ""
fetch("http://localhost:3000/news")
  .then(result => result.json())
  .then(data => {
    data.forEach(item => {
      let news = document.getElementById("news")
      template_news += `
        <div class="card mt-3 mx-2" style="max-width: 540px;">
          <div class="row g-0">
            <div class="col-md-4">
            <img src="${item.img}" class="img-fluid rounded-start" alt="img-news" style="height: 100%; width: auto">
          </div> 
            <div class="col-md-8">
              <div class="card-body">
                <h5 class="card-title">${item.title}</h5>
                <p class="card-text">${item.content}</p>
                <p class="card-text"><small class="text-body-secondary">${item.publicationDate}</small></p>
              </div>
            </div>
          </div>
        </div>
        `
        news.innerHTML = template_news
    })
  })
  